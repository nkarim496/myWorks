<?php if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Class NF_Field_Textbox
 */
// class NF_Fields_Color extends NF_Abstracts_Input
// {
//     protected $_name = 'color';

//     protected $_section = 'misc';

//     protected $_aliases = array( 'input' );

//     protected $_type = 'color';

//     protected $_templates = 'color';

//     public function __construct()
//     {
//         parent::__construct();

//         $this->_settings = $this->load_settings(
//             array( 'label', 'label_pos', 'required', 'classes' )
//         );

//         $this->_nicename = __( 'Color', 'ninja-forms' );
//     }
// }
