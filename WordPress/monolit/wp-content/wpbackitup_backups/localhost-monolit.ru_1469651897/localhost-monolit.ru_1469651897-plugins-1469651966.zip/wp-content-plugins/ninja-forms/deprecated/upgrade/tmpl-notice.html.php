<div id="nf-admin-notice-upgrade" class="update-nag nf-admin-notice" style="display: none;">
    <div class="nf-notice-logo"></div>
    <p class="nf-notice-title">Achievement Unlocked</p>
    <p class="nf-notice-body">
        Cowabunga! You just unlocked the Ninja Forms THREE release candidate.
    </p>
    <ul class="nf-notice-body nf-red">
        <li><span class="dashicons dashicons-awards"></span><a href="<?php echo admin_url( 'admin.php?page=ninja-forms-three' ); ?>">Upgrade to the Release Candidate</a></li>
    </ul>
</div>